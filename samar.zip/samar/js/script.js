$(function () {
  // Hiệu ứng cuộn trang (WOW.js + animate.css)
  if (window.WOW) {
    new WOW({ boxClass: 'wow', animateClass: 'animate__animated', offset: 60, mobile: true, live: true }).init();
  }

  // Đếm số (Waypoints + Counter-Up)
  if ($.fn.counterUp) $('.counter').counterUp({ delay: 10, time: 1500 });

  // Phóng to ảnh portfolio (Magnific Popup)
  if ($.fn.magnificPopup) {
    $('.portfolio__content').magnificPopup({ delegate: 'a', type: 'image', gallery: { enabled: true } });
  }

  // Menu mobile
  $('.burger').on('click', function () { $('nav').toggleClass('open'); });
  $('nav a').on('click', function () { $('nav').removeClass('open'); });

  // Cuộn mượt tới mục
  $('a[href^="#"]').not('[href="#"]').on('click', function (e) {
    var $t = $(this.hash);
    if ($t.length) { e.preventDefault(); $('html,body').animate({ scrollTop: $t.offset().top }, 700); }
  });

  // Nút lên đầu trang (hiện sau 300px)
  var $top = $('.backToTop');
  $(window).on('scroll', function () {
    $top.toggleClass('cd-top--is-visible', $(this).scrollTop() > 300);
  });
  $top.on('click', function (e) {
    e.preventDefault();
    $('html,body').animate({ scrollTop: 0 }, 700);
  });

  // Form newsletter
  $('.footer__form form').on('submit', function (e) { e.preventDefault(); this.reset(); });
});